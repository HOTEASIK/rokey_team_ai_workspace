#!/usr/bin/env python3
"""외부 탐색 — /process/explore 액션 서버: pick_tap(물건 집기 → wall_tap → 반납) 으로 벽 크기(테두리)를 재고
결과를 Process 양식으로 돌려준다. 벽 안쪽 틈은 다음 단계 내부 탐색(/process/inner_explore, wall_scan_server)이 찾는다.

  hmi_server(process_runner) ─goal→ explore_server ─ros2 run→ pick_tap (자식 프로세스, 결과 파일은 wall_tap 과 같음)
                             ←result (wall[12], gaps)── ~/wall_scan_data/explore_run<id>_*.json 읽기

  wall     : top / floor / right / left 각 [x,y,z] (BASE mm). 벽 표면 위, 높이·너비 측정선 기준
  gaps     : robot.yaml explore.gaps (손으로 넣는 값. 내부 탐색을 켜면 HMI 는 이 값 대신 내부 탐색 결과를 저장)

  [벽 좌표 직접 입력] robot.yaml explore.wall 에 4점이 있으면 pick_tap/wall_tap 을 실행하지 않고(로봇 안 움직임)
  그 값을 그대로 result.wall 로 돌려준다 (virtual 시험용 · 벽을 이미 알 때). 비우면 실제 측정.
  goal 마다 robot.yaml 을 새로 읽으므로 서버를 다시 켜지 않아도 된다.
  feedback : wall_tap 단계(floor / wall / height / width)마다 1번 → task_log 1줄 (params = robot.yaml wall_tap 값)

로봇은 wall_tap 이 움직이고, 이 서버는 움직이지 않는다.
웹 시작 버튼이 확인 역할이므로 wall_tap 의 y 입력 확인(confirm)은 끈다.
취소(웹 정지/비상정지): wall_tap 일시정지 → move_stop(QSTOP) → 강제 종료 → 힘/순응 해제.
  자동 홈 복귀는 하지 않는다 (정지 뒤 로봇이 스스로 움직이지 않게).

실행 (bringup 과 같은 mode):
  ros2 run rokey1 explore_server --ros-args -p mode:=virtual
"""
import json
import os
import signal
import threading
import statistics
import time
from datetime import datetime

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.signals import SignalHandlerOptions
from dsr_msgs2.srv import MoveStop, ReleaseComplianceCtrl, ReleaseForce
from rokey_interfaces.action import Process

from navigation.wall_size import DIRECTIONS, SAVE_DIR, UP_AXIS
from utils import config
from utils.config import CFG
from utils.robot import ROBOT_ID
from utils.worker_process import WorkerProcess

DR_QSTOP = 1


def wall_corners(data, trim=0.0):
    """wall_tap 결과 JSON → [top, floor, right, left] xyz 12개. 높이/너비가 없으면 ValueError.
    trim: 좌/우 끝을 각각 가운데 쪽으로 줄이는 거리 [mm] (robot.yaml explore.width_trim)
          손끝(그리퍼) 너비 탐색은 손가락 폭만큼 끝을 바깥으로 잼 (run169: 측정 520.3 / 실제 ≈497)

    옆/위 좌표는 측정 결과(중앙값), 벽 쪽 좌표는 그 모서리에서 가장 가까운 벽 접촉점의 실측값
    → 벽이 기울어 있으면 4점에 그대로 남는다 (법선은 utils/wall.wall_normal 로 계산).
    """
    app_axis, _, lat_axis, _ = DIRECTIONS[data['direction']]
    hits = [t['xyz'] for t in data['taps'] if t['hit'] and t['kind'] != 'floor']
    lines = [ln for ln in data['width_lines'] if ln['ok']]
    if 'top_z' not in data['results'] or not lines or not hits:
        raise ValueError('높이/너비 결과 없음')

    def pt(lat, up):
        near = min(hits, key=lambda h: (h[lat_axis] - lat) ** 2 + (h[UP_AXIS] - up) ** 2)
        p = [0.0, 0.0, 0.0]
        p[lat_axis], p[app_axis], p[UP_AXIS] = lat, float(near[app_axis]), up
        return p

    z = statistics.median(ln['up'] for ln in lines)
    right = statistics.median(ln['edges']['right']['edge'] for ln in lines)
    left = statistics.median(ln['edges']['left']['edge'] for ln in lines)
    c = data['lat_center']
    if trim:
        right += float(trim) * (1.0 if c > right else -1.0)     # 가운데 쪽으로
        left += float(trim) * (1.0 if c > left else -1.0)
        if (left - c) * (right - c) >= 0:
            raise ValueError(f'width_trim {trim:g}mm 가 너무 큼 (좌 {left:.1f} / 우 {right:.1f} / 가운데 {c:.1f})')
    return pt(c, data['results']['top_z']) + pt(c, data['floor_z']) + pt(right, z) + pt(left, z)


def manual_wall(cfg=None):
    """robot.yaml explore.wall [[위 xyz], [바닥 xyz], [오른쪽 xyz], [왼쪽 xyz]] → 12개 한 줄. 비어 있으면 []."""
    pts = ((cfg or CFG).get('explore') or {}).get('wall') or []
    if not pts:
        return []
    if len(pts) != 4 or any(len(p) != 3 for p in pts):
        raise ValueError(f'robot.yaml explore.wall 은 [위, 바닥, 오른쪽, 왼쪽] 각 [x,y,z] 4점: {pts}')
    top, floor, right, left = [[float(v) for v in p] for p in pts]
    if left[1] <= right[1] or top[2] <= floor[2]:
        raise ValueError(f'robot.yaml explore.wall: 왼쪽 Y > 오른쪽 Y, 위 Z > 바닥 Z 여야 함: {pts}')
    return top + floor + right + left


def manual_gaps(cfg=None):
    """robot.yaml explore.gaps → [sx,sy,sz, ex,ey,ez, ...] 한 줄로."""
    out = []
    for g in ((cfg or CFG).get('explore') or {}).get('gaps') or []:
        if len(g) != 6:
            raise ValueError(f'robot.yaml explore.gaps 는 [sx,sy,sz, ex,ey,ez] 6개씩: {g}')
        out += [float(v) for v in g]
    return out


class ExploreServer(Node):
    def __init__(self):
        super().__init__('explore_server')
        self.mode = self.declare_parameter('mode', 'virtual').value
        self.busy = False
        self.worker = None   # 실행 중 wall_tap (서버가 꺼질 때 같이 끄려고)
        cb = ReentrantCallbackGroup()
        ctrl = f'/{ROBOT_ID}/dsr_controller2'
        self.cli = {key: self.create_client(srv, f'{ctrl}/{name}', callback_group=cb) for key, srv, name in (
            ('stop', MoveStop, 'motion/move_stop'),
            ('force', ReleaseForce, 'force/release_force'),
            ('compliance', ReleaseComplianceCtrl, 'force/release_compliance_ctrl'))}
        ActionServer(self, Process, '/process/explore', self.execute, callback_group=cb,
                     goal_callback=lambda _: GoalResponse.REJECT if self.busy else GoalResponse.ACCEPT,
                     cancel_callback=lambda _: CancelResponse.ACCEPT)
        self.get_logger().info(f'외부 탐색 /process/explore 준비 (mode={self.mode}). goal 전에는 움직이지 않습니다.')

    def execute(self, gh):
        self.busy = True
        try:
            return self._run(gh)
        finally:
            self.busy = False

    def _run(self, gh):
        run_id = gh.request.run_id
        try:
            cfg = config.load()
            wall = manual_wall(cfg)
        except (OSError, ValueError) as e:
            gh.abort()
            return Process.Result(success=False, error_code='E_EXPLORE', message=str(e))
        if wall:
            return self._manual(gh, wall, cfg)
        out = os.path.join(SAVE_DIR, f'explore_run{run_id}_{datetime.now():%Y%m%d_%H%M%S}.json')
        worker = WorkerProcess(['ros2', 'run', 'rokey1', 'pick_tap', '--ros-args',
                                '-p', f'mode:={self.mode}', '-p', 'confirm:=false', '-p', 'rviz:=false',
                                '-p', f'out:={out}', '-p', f'tag:=run{run_id}'])
        self.worker = worker
        limit = float(CFG['explore']['timeout_sec'])
        t0 = time.time()
        while worker.poll() is None:
            self._echo(worker)
            if gh.is_cancel_requested or time.time() - t0 > limit:
                self._abort(worker)
                if gh.is_cancel_requested:
                    gh.canceled()
                    return Process.Result(success=False, error_code='CANCELED', message='취소됨')
                gh.abort()
                return Process.Result(success=False, error_code='E_TIMEOUT', message=f'wall_tap {limit:.0f}s 초과')
            time.sleep(0.1)
        self._echo(worker)

        try:
            with open(out) as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            gh.abort()
            return Process.Result(success=False, error_code='E_EXPLORE', message=f'wall_tap 결과 없음: {e}')

        params = json.dumps({k: data['config'].get(k) for k in CFG.get('wall_tap') or {}})
        for name, sec in data['metrics']['phase_time'].items():
            gh.publish_feedback(Process.Feedback(state='RUNNING', step=f'explore_{name}', step_success=True,
                                                 duration_ms=int(sec * 1000), params_json=params))
        try:
            if data['status'] != 'ok':
                raise ValueError(data.get('error') or data['status'])
            trim = float((cfg.get('explore') or {}).get('width_trim') or 0.0)
            wall, gaps = wall_corners(data, trim), manual_gaps()
        except (ValueError, KeyError) as e:
            gh.abort()
            return Process.Result(success=False, error_code='E_EXPLORE', message=str(e))
        gh.succeed()
        r = data['results']
        return Process.Result(success=True, wall=wall, gaps=gaps,
                              message=f'높이 {r["height"]["median"]:.1f} / 너비 {abs(wall[10] - wall[7]):.1f} mm '
                                      f'(측정 {r["width"]["median"]:.1f} − 좌우 {trim:g}mm씩), '
                                      f'틈 {len(gaps) // 6}개 ({os.path.basename(out)})')

    def _manual(self, gh, wall, cfg):
        """robot.yaml explore.wall 그대로 돌려줌 (로봇 안 움직임)."""
        try:
            gaps = manual_gaps(cfg)
        except ValueError as e:
            gh.abort()
            return Process.Result(success=False, error_code='E_EXPLORE', message=str(e))
        self.get_logger().warn(f'robot.yaml explore.wall 사용 → 벽 측정 건너뜀 (로봇 안 움직임): {wall}')
        gh.publish_feedback(Process.Feedback(state='RUNNING', step='explore_manual_wall', step_success=True,
                                             duration_ms=0, params_json=json.dumps({'wall': wall})))
        gh.succeed()
        return Process.Result(success=True, wall=wall, gaps=gaps,
                              message=f'robot.yaml explore.wall 사용 (측정 안 함), 틈 {len(gaps) // 6}개')

    def _echo(self, worker):
        for line in worker.drain():
            self.get_logger().info(f'[wall_tap] {line}')

    def _abort(self, worker):
        """다음 명령 막기 → 즉시 정지 → 강제 종료(홈 복귀 안 함) → 힘/순응 해제."""
        worker.freeze()
        self._call('stop', MoveStop.Request(stop_mode=DR_QSTOP))
        worker.kill()
        self._call('force', ReleaseForce.Request(time=0.0))
        self._call('compliance', ReleaseComplianceCtrl.Request())

    def _call(self, key, req, timeout=2.0):
        cli = self.cli[key]
        if not cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().error(f'{cli.srv_name} 서비스 없음')
            return
        fut = cli.call_async(req)
        t0 = time.time()
        while not fut.done() and time.time() - t0 < timeout:
            time.sleep(0.02)


def main(args=None):
    # 서버가 꺼질 때도 정지 명령을 보낼 수 있게 ROS 연결을 먼저 끊지 않는다 (SIGINT·SIGTERM → KeyboardInterrupt)
    rclpy.init(args=args, signal_handler_options=SignalHandlerOptions.NO)
    signal.signal(signal.SIGTERM, signal.default_int_handler)
    node = ExploreServer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        while rclpy.ok():
            executor.spin_once(timeout_sec=0.1)   # spin() 은 이벤트가 올 때까지 신호를 못 받아 정지가 몇 분 늦었음
    except KeyboardInterrupt:
        pass
    finally:
        # 탐색 중이면: 다음 명령 막기 → 로봇 즉시 정지 → wall_tap 종료 → 힘/순응 해제 (wall_tap 은 별도 세션이라 안 하면 고아로 남음)
        if node.worker and node.worker.poll() is None:
            node.get_logger().warn('서버 종료: 실행 중인 탐색을 멈춥니다.')
            threading.Thread(target=executor.spin, daemon=True).start()   # 정지 서비스 응답 받기용
            node._abort(node.worker)
        executor.shutdown()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
